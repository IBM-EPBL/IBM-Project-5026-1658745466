# IBM-Project-48229-1660805792
Inventory Managment System for Retailers
